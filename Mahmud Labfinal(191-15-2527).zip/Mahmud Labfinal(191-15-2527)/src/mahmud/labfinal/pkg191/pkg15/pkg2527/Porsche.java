
package mahmud.labfinal.pkg191.pkg15.pkg2527;


public class Porsche extends car implements Headlights,Fan {
          
   private int ProductionYear;
   private int numberofseats;
   private String speed;

    public Porsche(int ProductionYear, int numberofseats, String speed, String Color, String type) {
        super(Color, type);
        this.ProductionYear = ProductionYear;
        this.numberofseats = numberofseats;
        this.speed = speed;
    }

    public int getProductionYear() {
        return ProductionYear;
    }

    public void setProductionYear(int ProductionYear) {
        this.ProductionYear = ProductionYear;
    }

    public int getNumberofseats() {
        return numberofseats;
    }

    public void setNumberofseats(int numberofseats) {
        this.numberofseats = numberofseats;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    @Override
    public void setColor(String Color) {
       this.Color=Color;
    }

    @Override
    public void setType(String type) {
       this.type=type;
    }

    @Override
    public void sparkigniter() {
        System.out.println("Porsche Start igniter");
    }

    @Override
    public void stopigniter() {
        System.out.println("Porsche stop igniter");
    }

    @Override
    public void startLight() {
        System.out.println("Porsche Lights On");
    }

    @Override
    public void stoptLight() {
        System.out.println("Porsche Lights Off");
    }

    @Override
    public void startFan() {
        System.out.println("Porsche Fan On");
    }

    @Override
    public void stoptFan() {
        System.out.println("Porsche Fan Off");
    }

 
       
    
}

