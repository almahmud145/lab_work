
package mahmud.labfinal.pkg191.pkg15.pkg2527;

public abstract class car implements igniter {
    protected String Color;
    protected String type;

    public car(String Color, String type) {
        this.Color = Color;
        this.type = type;
    }

    public String getColor() {
        return Color;
    }

    public abstract void setColor(String Color);
        
    

    public String getType() {
        return type;
    }

    public abstract void setType(String type); 
        
    
    
}
