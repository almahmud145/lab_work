
package mahmud.labfinal.pkg191.pkg15.pkg2527;

public interface AC {
    public abstract void startAC();
    public abstract void stoptAC();
}