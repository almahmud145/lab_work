
package mahmud.labfinal.pkg191.pkg15.pkg2527;


public class Lamborghini extends car implements Fan,Headlights,AC {
    
     private int ProductionYear;
     private int numberofseats;

    public int getProductionYear() {
        return ProductionYear;
    }

    public void setProductionYear(int ProductionYear) {
        this.ProductionYear = ProductionYear;
    }

    public int getNumberofseats() {
        return numberofseats;
    }

    public void setNumberofseats(int numberofseats) {
        this.numberofseats = numberofseats;
    }

    public Lamborghini(int ProductionYear, int numberofseats, String Color, String type) {
        super(Color, type);
        this.ProductionYear = ProductionYear;
        this.numberofseats = numberofseats;
    }

    @Override
    public void setColor(String Color) {
       this.Color=Color;
    }

    @Override
    public void setType(String type) {
     this.type=type;
    }

    @Override
    public void sparkigniter() {
        System.out.println("Lamborghini spark Igniter");
    }

    @Override
    public void stopigniter() {
        System.out.println("Lamborghini Stop Igniter");
    }

    @Override
    public void startLight() {
        System.out.println("Lamborghini Lights ON");
    }

    @Override
    public void stoptLight() {
        System.out.println("Lamborghini Lights OFF");
    }

    @Override
    public void startFan() {
        System.out.println("Lamborghini Fan Started");
    }

    @Override
    public void stoptFan() {
        System.out.println("Lamborghini Fan switched off");
    }

    @Override
    public void startAC() {
        System.out.println("Lamborghini AC Started");
    }

    @Override
    public void stoptAC() {
        System.out.println("Lamborghini AC Stoped");
    }
    public static void main(String[] args) {
        Lamborghini l= new Lamborghini(2009,2,"Blackish Blue","Marsidies Car");
        
        System.out.println("Information of Lamborghini Car\n");
        System.out.println("ProductionYear ="+l.ProductionYear);
        System.out.println("numberofseats="+l.numberofseats);
        System.out.println("Color="+l.Color);
        System.out.println("Type="+l.type);
        l.stoptAC();
        l.startAC();
        l.startFan();
        l.stoptFan();
        l.startLight();
        l.stoptLight();
        l.sparkigniter();
        l.stopigniter();
        System.out.println("\n\n");
        Porsche p=new Porsche(2010,4,"200 Mile/Hour","Gradiant Sky","Luxury Car");
        System.out.println("Information of Porsche Car\n");
        
        System.out.println("ProductionYear ="+p.getProductionYear());
        System.out.println("numberofseats="+p.getNumberofseats());
        System.out.println("speed="+p.getSpeed());
        System.out.println("Color="+p.Color);
        System.out.println("Type="+p.type);
        p.startFan();
        p.startFan();
        p.startLight();
        p.stoptLight();
        p.sparkigniter();
        p.stopigniter();
        
    }
    
    
}

