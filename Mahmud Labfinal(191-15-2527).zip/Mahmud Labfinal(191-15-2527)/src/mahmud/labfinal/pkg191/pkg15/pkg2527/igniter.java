
package mahmud.labfinal.pkg191.pkg15.pkg2527;

public interface igniter {
   public abstract void sparkigniter();
    public abstract void stopigniter();  
}

