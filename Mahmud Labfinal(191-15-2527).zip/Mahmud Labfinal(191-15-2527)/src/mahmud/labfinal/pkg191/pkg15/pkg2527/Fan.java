
package mahmud.labfinal.pkg191.pkg15.pkg2527;



public interface Fan {
     public abstract void startFan();
     public abstract void stoptFan();
}