
package mahmud.labfinal.pkg191.pkg15.pkg2527;

public interface Headlights {
    public abstract void startLight();
     public abstract void stoptLight();
}

